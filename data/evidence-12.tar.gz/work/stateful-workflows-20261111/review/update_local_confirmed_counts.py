"""Archive the prior index, then write derived local mechanism/root counts.

No install, network request, raw-evidence edit or issue01 edit is performed.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
ISSUES = ROOT / "1110ISSUEs"
REVIEW = ROOT / "work/stateful-workflows-20261111/review"


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evidence(path):
    assert path.is_file(), str(path)
    return {"path": str(path.relative_to(ROOT)), "sha256": digest(path)}


def write_json(path, value):
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def link(label, path):
    assert path.is_file(), str(path)
    return "[" + label + "](D:/wsl/personal/dr/paper/FSE2027DependencyResolution/" + str(path.relative_to(ROOT)) + ")"


now = datetime.now(timezone.utc).isoformat()
index = ISSUES / "README.md"
old_index = index.read_bytes()
old_index_sha = hashlib.sha256(old_index).hexdigest()
assert old_index_sha == "3decdafecc699a87904b5fc53c2050ae2a401b14ce441ee4be50900aeea15caa"
issue01 = evidence(ISSUES / "01-astral-sh__uv.md")
issue02 = evidence(ISSUES / "02-ultralytics__ultralytics.md")
assert issue01["sha256"] == "3d495e12a9fe7d1018510aeedc6e5972c51f38dbd040bf9e051e55c6794ad4fa"
assert issue02["sha256"] == "372fd37d19767da75534d282918f1290e39917e1cc56584b00984332a1ffe666"
ledger_path = ISSUES / "confirmed-ledger.json"
counts_path = ISSUES / "current-counts.json"
assert not ledger_path.exists() and not counts_path.exists()
for required in ["outputs/1111-expansion-validation-report.md", "outputs/1111-expansion-validation-report.json", "outputs/1110-validation-report.md", "1110ISSUEs/01-uv-source-reuse-repro.py"]:
    assert (ROOT / required).is_file(), required

# Persist and verify the exact prior index before any index mutation.
archive_dir = REVIEW / "count-ledger-readme-archive-20261111"
assert not archive_dir.exists()
archive_dir.mkdir()
archive = archive_dir / ("README.before-two-mechanism-ledger." + old_index_sha[:12] + ".md")
archive.write_bytes(old_index)
assert digest(archive) == old_index_sha
archive_manifest = archive_dir / "archive.json"
write_json(archive_manifest, {
    "schema": "local-issue-index-before-count-update-archive-v1", "archived_at_utc": now,
    "original": {"path": "1110ISSUEs/README.md", "sha256": old_index_sha},
    "archive": evidence(archive), "issue01_preserved_identity": issue01,
    "scope": "Byte-identical README archive before adding the second locally reproduced category and first confirmed real root. Issue01 and all raw evidence remain unchanged.",
})

m1_review_path = ROOT / "work/expanded-validation-20261111/install-review/uv-closure-review.json"
m1_review = load(m1_review_path)
assert m1_review["independent_mechanisms"] == 1 and len(m1_review["runs"]) == 3
m1_runs = []
for run in m1_review["runs"]:
    path = ROOT / run["directory"] / "results.json"
    assert digest(path) == run["results_sha256"]
    assert run["checks_reported_true"] == run["checks_reported_total"] == 19
    m1_runs.append(evidence(path))
assert digest(ROOT / m1_review["final_delivery_script"]) == m1_review["final_delivery_script_sha256"]

admission_path = REVIEW / "ultralytics-extra-final-admission.json"
admission = load(admission_path)
assert digest(admission_path) == "787db1765bdb43ae98e814492b711c3faf98a2dc17fe5dd2154675bb2fefb4aa"
assert admission["counts"]["independent_real_trigger_repetitions"] == 2
assert admission["counts"]["new_real_affected_canonical_root_projects"] == 1
assert admission["selection_provenance"]["supplemental_targeted_extra"]
assert not admission["selection_provenance"]["replaces_original_min_extra_sample"]
m2_refs = {}
for label, value in {
    "manual_admission": evidence(admission_path),
    "primary_full_actual_run": admission["actual_result"],
    "primary_protocol": admission["protocol"],
    "independent_root_actual_run": admission["independent_actual_repetition"]["result"],
    "independent_root_protocol": admission["independent_actual_repetition"]["protocol"],
    "yolo_import_controls": admission["yolo_import_controls"],
    "original_data_path_addendum": admission["original_data_mapping_addendum"],
    "official_upstream_duplicate_review": admission["upstream_review"],
    "namespace_provider_overlap": admission["namespace_overlap"],
    "resource_footprint_observation": admission["resource_footprint_observation"],
    "frozen_reproduction_inputs": evidence(ISSUES / "02-ultralytics-extra-inputs/inputs.json"),
}.items():
    assert digest(ROOT / value["path"]) == value["sha256"], label
    m2_refs[label] = value
root_run = load(ROOT / m2_refs["independent_root_actual_run"]["path"])
assert m2_refs["independent_root_actual_run"]["sha256"] == "724f121c7b7229cd5701e91d58faca9d455a1a182ffe33a7b780eab326497f46"
assert root_run["same_final_inputs"]
root_stages = {stage["label"]: stage for stage in root_run["stages"]}
assert root_stages["base-restored"]["normal_cv2_missing"] == 39
assert root_stages["base-restored"]["yolo_import_exit"] == 1
assert root_stages["repair-opencv-only"]["normal_cv2_missing"] == 0
assert root_stages["repair-opencv-only"]["yolo_import_exit"] == 0

wording = "累计确认2类本地可复现机制：M1仅由人工fixture验证，真实根项目0；M2在Ultralytics官方extra流程中验证，真实根项目1。本轮新确认1个真实项目实例；已证新uv机制0，已证全生态新颖问题0。"
counts = {
    "local_reproducible_mechanism_categories": 2,
    "mechanism_categories_with_only_synthetic_fixture": 1,
    "mechanism_categories_with_real_root_witness": 1,
    "cumulative_confirmed_real_canonical_roots": 1,
    "cumulative_confirmed_real_upstream_repositories": 1,
    "newly_confirmed_real_roots_this_round": 1,
    "established_new_uv_mechanisms": 0,
    "established_ecosystem_wide_novel_issues": 0,
    "local_issue_descriptions": 2,
    "public_issues_submitted": 0,
    "public_comments_posted": 0,
}
real_root = {
    "canonical_distribution": "ultralytics", "upstream_repository": "ultralytics/ultralytics",
    "root_dedup_key": "ultralytics|ultralytics/ultralytics", "mechanism_ids": ["M2"],
    "tested_version": "8.4.208", "tested_runtime_extra": "extra",
    "scope": "Complete official CPU consumer configuration; repeated original torch/torchvision requirements activate their official CPU named source. All other artifacts are official PyPI. No metadata edits, no no-deps, no GPU application claim.",
    "supplemental_targeted_extra": True, "replaces_original_fixed_min_extra_sample": False,
    "newly_confirmed_instance_in_this_round": True,
    "first_known_affected_project_in_ecosystem_claim": False,
}
ledger = {
    "schema": "dependency-resolution-confirmed-ledger-v1", "created_at_utc": now,
    "scope": "Derived local reproduction and affected-root accounting; independent from upstream novelty, number of issue descriptions, dependency nodes, file paths and repetitions. Original raw results and issue01 are preserved.",
    "summary_zh": wording, "counts": counts,
    "counting_rules": {
        "mechanism_identity": "Distinct root-cause family, counted once across entry points, versions, fixtures and repetitions.",
        "real_root_identity": "Verified canonical distribution and its upstream repository pair; also report unique upstream repositories separately.",
        "synthetic_fixture_is_real_root": False,
        "dependency_chain_node_is_additional_root": False,
        "issue_description_is_mechanism_or_root_count_basis": False,
        "file_path_or_audit_entry_is_mechanism_count_basis": False,
        "zero_established_novelty_meaning": "No additional mechanism/issue has been proved novel upstream or ecosystem-wide; local reproducibility is recorded separately.",
        "newly_confirmed_instance_meaning": "New confirmation under this research protocol, not first discovery or first known ecosystem impact.",
    },
    "mechanisms": [
        {
            "id": "M1", "label_zh": "同版本来源复用导致已安装依赖闭包不一致",
            "root_cause_family": "same-version-registry-source-reuse-with-stale-installed-metadata",
            "local_reproduction_confirmed": True,
            "owner_roles": {"tool_under_test": "uv", "tool_repository": "astral-sh/uv", "local_issue_target": "astral-sh/uv", "consumer_project": "Inert locally constructed fixture; no real affected root established."},
            "witness_scope": {"type": "synthetic_inert_wheels", "independent_actual_repetitions": 3, "checks_each_repetition": 19, "real_root_count": 0, "real_roots": [], "tested_uv": "0.13.7", "native_target": "CPython3.11.16 Linux x86_64"},
            "observed_contract": "Successful warm locked sync retains old same-version probe metadata requiring old-dep, removes old-dep and installs new-dep. Both dependency checkers fail; identical-final-input fresh/reinstall controls pass.",
            "novelty": {"new_uv_mechanism_established": False, "ecosystem_wide_novel_issue_established": False, "upstream_maintainer_acceptance_of_exact_closure_case": False, "status": "Known source-reuse family; exact closure-case novelty remains unestablished.", "related_primary_sources": m1_review["upstream_novelty"]["known_family"]},
            "local_issue": issue01, "admission_review": evidence(m1_review_path), "actual_runs": m1_runs,
            "standalone_reproducer": evidence(ROOT / m1_review["final_delivery_script"]),
            "excluded_real_project_claims": ["Torch", "vLLM", "CUDA applications", "fixture package names"],
        },
        {
            "id": "M2", "label_zh": "互斥provider共装与移除时删除保留包共享文件",
            "root_cause_family": "mutually-exclusive-namespace-providers-with-shared-file-removal",
            "local_reproduction_confirmed": True,
            "owner_roles": {"observed_transition_tool": "uv", "tool_repository": "astral-sh/uv", "comparison_tool": "pip", "dependency_declaration_owner": "ultralytics/ultralytics", "local_issue_target": "ultralytics/ultralytics", "provider_repository": "opencv/opencv-python", "dependency_chain_nodes_not_counted_as_roots": ["opencv-python", "opencv-python-headless", "albumentations", "torch", "torchvision"]},
            "witness_scope": {"type": "complete_official_real_package_request", "independent_actual_trigger_repetitions": 2, "real_root_count": 1, "real_roots": [real_root], "tested_uv": "0.13.7", "native_target": "CPython3.11.16 Linux x86_64", "cold_fresh_same_final_input": True, "full_forced_reinstall_control": True, "independent_opencv_only_repair_control": True},
            "observed_contract": "Ultralytics base requires normal OpenCV; its extra selects Albumentations requiring headless OpenCV. Cancelling extra removes39 shared cv2 paths still required by the retained normal provider. Metadata closure and both checkers pass, but cvtColor and YOLO import fail. Same-final-input cold fresh/full reinstall and independent provider-only repair restore the files/imports.",
            "raw_counts_not_independent_defects": {"shared_missing_paths": 39, "duplicate_original_and_record_violation_entries": 78, "original_conflicting_provider_paths": 3, "real_root_count": 1},
            "novelty": {"new_uv_mechanism_established": False, "ecosystem_wide_novel_issue_established": False, "first_known_ultralytics_impact_claim": False, "same_installer_mechanism_already_reported": {"url": "https://github.com/astral-sh/uv/issues/19412", "relation": "Known normal/contrib cv2 shared-file removal/recovery mechanism."}, "same_project_prior_symptom": {"url": "https://github.com/ultralytics/ultralytics/issues/16939#issuecomment-3731822287", "date": "2026-01-10", "relation": "Already reports uv sync, missing cv2.imshow and removal/re-add recovery; exact official-extra/Albumentations path was not established in the captured discussion."}, "status": "Newly confirmed real-project workflow witness within this protocol for a known conflict family; no upstream first-discovery claim."},
            "local_issue": issue02, "evidence": m2_refs,
            "internal_research_counting_approval": {"source": "Parent agent /root explicit task message, 2026-11-11", "approved_real_project_count": 1, "basis": "Root read issue02/admission and independently executed all four transition/repair steps.", "is_upstream_maintainer_acceptance": False},
            "raw_execution_classification_preserved": {"root_result_status": root_run["status"], "root_result_automatic_confirmed_defects": root_run["confirmed_defects"], "derived_manual_admission_is_counting_authority": True},
        },
    ],
    "counted_real_roots": [real_root],
    "local_issue_descriptions": [{"number": "01", "mechanism_id": "M1", **issue01}, {"number": "02", "mechanism_id": "M2", **issue02}],
    "previous_readme_archive": evidence(archive), "archive_manifest": evidence(archive_manifest),
    "writer": evidence(Path(__file__).resolve()),
    "limits": ["Only the registered native uv0.13.7 and package inputs are confirmed; current newer declarations were checked statically, not installed.", "M2 is a separately registered targeted extra supplement; the original fixed min-extra workflow sample and static extra counts are unchanged.", "Pip's ordinary base request retaining extra dependencies is expected incremental behavior and contributes no second mechanism.", "No application inference, GPU execution, ecosystem prevalence, package-wide no-bug or complete-public-index comparison is claimed.", "No public issue or comment has been submitted; known reports and unresolved upstream novelty remain explicit."],
}
assert len(ledger["mechanisms"]) == counts["local_reproducible_mechanism_categories"]
assert len({r["root_dedup_key"] for r in ledger["counted_real_roots"]}) == counts["cumulative_confirmed_real_canonical_roots"]
assert len({r["upstream_repository"] for r in ledger["counted_real_roots"]}) == counts["cumulative_confirmed_real_upstream_repositories"]
write_json(ledger_path, ledger)

readme = """# 1110/1111 依赖问题本地报告

截至2026-11-11，累计确认 **2类本地可复现机制**，真实受影响根项目为 **1个：Ultralytics**。本轮新确认1个真实项目实例；**已证新uv机制0，已证全生态新颖问题0**。所有描述均保存在本地，尚未公开提交。

机制按根因去重；issue稿、复现轮次、文件路径、检查条目和依赖链节点分别记录，不参与机制或真实项目计数。“本轮新确认”表示本研究新增了可复验的实例证据，新颖性另行审计。

| 机制 | 本地可复现观察 | 验证范围 | 真实根项目 | 工具/项目归属 | 上游新颖性 |
|---|---|---|---:|---|---|
| M1 | 同版来源切换并重锁后，成功sync留下不满足已安装Requires-Dist的环境；fresh/reinstall正常 | 人工无代码wheel fixture，3轮实际执行 | 0 | 工具：uv；01目标：astral-sh/uv | 来源复用家族已有讨论；本闭包入口新颖性未确证 |
| M2 | 官方extra同时要求互斥OpenCV发行包；取消extra后删除保留包的39个共享cv2文件，YOLO导入失败 | Ultralytics8.4.208官方完整CPU请求，2轮真实迁移及相同最终输入的cold fresh/full repair/定点修复 | 1 | 声明组合：ultralytics/ultralytics；迁移工具：uv；provider：OpenCV | uv #19412机制已知，Ultralytics #16939已有同项目旧症状 |

M1的人工fixture不计真实受影响项目。M2仅计canonical发行包`ultralytics`及其对应仓库`ultralytics/ultralytics`；OpenCV、Albumentations、Torch等依赖链节点不另计项目。工具所属仓库与受影响根项目分别列出。

M2补证的是官方`extra`→Albumentations→headless OpenCV的完整真实流程。它使用已冻结的重要包版本及明确的官方CPU来源配置，是原固定min-extra样本之外的追加测试。pip再次请求基础包后保留extra依赖属于正常增量语义，不增加问题或机制计数。

**已有报告须同时阅读：** [uv #19412](https://github.com/astral-sh/uv/issues/19412)已报告共享cv2文件移除机制；[Ultralytics #16939的2026-01-10反馈](https://github.com/ultralytics/ultralytics/issues/16939#issuecomment-3731822287)已记载uv sync后cv2.imshow缺失及移除重加恢复。当前证据支持“新确认的真实实例”，不支持“首次发现”或“新uv机制”的主张。

"""
readme += link("01：来源复用闭包问题", ISSUES / "01-astral-sh__uv.md") + " · " + link("01独立复现脚本", ISSUES / "01-uv-dependency-closure-repro.py") + " · " + link("原来源-only脚本", ISSUES / "01-uv-source-reuse-repro.py") + "\n\n"
readme += link("02：Ultralytics官方extra实装补充", ISSUES / "02-ultralytics__ultralytics.md") + " · " + link("02冻结manifest/lock输入索引", ISSUES / "02-ultralytics-extra-inputs/inputs.json") + " · " + link("02最终手工准入", admission_path) + " · " + link("Root独立第二轮实装", ROOT / m2_refs["independent_root_actual_run"]["path"]) + "\n\n"
# current-counts is created immediately after this index; avoid a hash cycle.
readme += link("机器可读机制与项目台账", ledger_path) + " · [当前统计](D:/wsl/personal/dr/paper/FSE2027DependencyResolution/1110ISSUEs/current-counts.json)\n\n"
readme += "01正文保持原字节不变。本次更新前的README已按SHA归档：" + link("归档README", archive) + "（SHA-256 `" + old_index_sha + "`）。原始runner中的自动0/pending分类保留，由单独的手工准入证书和此台账给出派生计数。\n\n"
readme += "既往检测材料：" + link("1111扩展检测报告", ROOT / "outputs/1111-expansion-validation-report.md") + " · " + link("1111合并数据", ROOT / "outputs/1111-expansion-validation-report.json") + " · " + link("1110历史报告", ROOT / "outputs/1110-validation-report.md") + "。这些历史报告各有原始范围和时间，当前确认计数以本页及current-counts为准；历史证据未回写。\n"
assert index.read_bytes() == old_index
index.write_text(readme)
assert evidence(ISSUES / "01-astral-sh__uv.md") == issue01
assert evidence(ISSUES / "02-ultralytics__ultralytics.md") == issue02

summary = {
    "schema": "dependency-resolution-current-counts-v1", "created_at_utc": now,
    "summary_zh": wording, "counts": counts,
    "mechanism_ids": ["M1", "M2"],
    "mechanism_summary": [{"id": "M1", "local_reproduction_confirmed": True, "real_root_count": 0, "scope": "synthetic_inert_wheels", "owner_tool_repository": "astral-sh/uv", "local_issue_target": "astral-sh/uv"}, {"id": "M2", "local_reproduction_confirmed": True, "real_root_count": 1, "scope": "official_complete_supplemental_extra_workflow", "owner_tool_repository": "astral-sh/uv", "declaration_owner_repository": "ultralytics/ultralytics", "local_issue_target": "ultralytics/ultralytics"}],
    "counted_real_roots": [real_root],
    "binding": {"confirmed_ledger": evidence(ledger_path), "current_readme": evidence(index), "previous_readme_archive": evidence(archive), "archive_manifest": evidence(archive_manifest), "issue01_unchanged": issue01, "issue02": issue02, "m1_admission": evidence(m1_review_path), "m2_admission": evidence(admission_path), "m2_primary_full_actual_result": m2_refs["primary_full_actual_run"], "m2_root_independent_final_result": m2_refs["independent_root_actual_run"], "m2_root_protocol": m2_refs["independent_root_protocol"], "m2_frozen_reproduction_inputs": m2_refs["frozen_reproduction_inputs"], "m2_upstream_novelty_review": m2_refs["official_upstream_duplicate_review"]},
    "novelty_boundary": {"newly_confirmed_real_instance_is_not_first_discovery": True, "known_uv_shared_file_mechanism": "https://github.com/astral-sh/uv/issues/19412", "known_ultralytics_runtime_symptom": "https://github.com/ultralytics/ultralytics/issues/16939#issuecomment-3731822287", "ecosystem_wide_search_exhaustiveness_claimed": False},
    "integration_rules": ["This file counts confirmed cases, not all52 selected roots or numbers of executed workflows.", "Keep the original fixed min-extra sample/static32-extra tally unchanged; Ultralytics extra is a separately preregistered additive test.", "Mechanisms, local issue descriptions, real root projects, upstream repositories, file paths and dependency nodes have separate units.", "Retain immutable raw automatic0/pending statuses and apply the independently bound manual counting ledger.", "No public issue/comment or upstream maintainer acceptance is implied."],
    "writer": evidence(Path(__file__).resolve()),
}
write_json(counts_path, summary)

# Verify the entire derived binding DAG without rehashing large payloads again.
verified = set()
def verify_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str) and len(value["sha256"]) == 64:
            path = ROOT / value["path"]
            assert digest(path) == value["sha256"], str(path)
            verified.add(str(path.relative_to(ROOT)))
        for child in value.values():
            verify_refs(child)
    elif isinstance(value, list):
        for child in value:
            verify_refs(child)
verify_refs(ledger)
verify_refs(summary)
assert digest(index) == summary["binding"]["current_readme"]["sha256"]
assert digest(archive) == old_index_sha
assert evidence(ISSUES / "01-astral-sh__uv.md") == issue01
print(json.dumps({"readme": evidence(index), "confirmed_ledger": evidence(ledger_path), "current_counts": evidence(counts_path), "archive": evidence(archive), "verified_bound_files": len(verified), "counts": counts}, ensure_ascii=False))
