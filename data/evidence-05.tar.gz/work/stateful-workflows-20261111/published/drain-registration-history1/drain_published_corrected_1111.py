"""Stop scheduling while two owned phases finish under their original902s caps."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import time

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'work/stateful-workflows-20261111/published/corrected-continuation1'
PLAN=SOURCE.parent/'drain-to-staged-plan.json'
LEDGER=SOURCE.parent/'drain-to-staged-record.json'
HELPER=ROOT/'scripts/recover_stateful_preparation_1111.py'
HELPER_SHA='a8e6c7021528e41a9829b51023cba5ed027597dbe90307b01bde83eaccb3c016'

def now():return datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):
 temporary=p.with_suffix(p.suffix+'.tmp');temporary.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');os.replace(temporary,p)
def process(pid):
 try:
  path=Path('/proc')/str(pid)
  if path.stat().st_uid!=os.getuid():return None
  text=(path/'stat').read_text();fields=text[text.rfind(')')+2:].split()
  return {'pid':int(pid),'state':fields[0],'ppid':int(fields[1]),'pgid':int(fields[2]),'start_ticks':int(fields[19]),'argv':(path/'cmdline').read_bytes().decode().strip('\0').split('\0')}
 except (OSError,ValueError,IndexError):return None
def all_processes():return [r for p in Path('/proc').iterdir() if p.name.isdigit() and (r:=process(p.name))]
def matches(row,mode):
 argv=row['argv']
 try:return str(HELPER) in argv and mode in argv and '--out' in argv and Path(argv[argv.index('--out')+1]).resolve()==SOURCE
 except (ValueError,IndexError):return False
def same(row):
 current=process(row['pid']);return current and current['start_ticks']==row['start_ticks']
def record_source_result(worker):
 argv=worker['argv'];name=argv[argv.index('--worker')+1];phase=argv[argv.index('--phase')+1]
 path=SOURCE/'cases'/name/phase/'results.json'
 return {'root':name,'phase':phase,'path':str(path),'exists':path.exists(),'sha256':sha(path) if path.exists() else None,'status':json.loads(path.read_text()).get('status') if path.exists() else None}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');args=parser.parse_args()
 assert os.name=='posix' and sha(HELPER)==HELPER_SHA
 if args.prepare:
  assert not PLAN.exists() and not LEDGER.exists()
  plan={'schema':'published-corrected900-safe-drain-v1','registered_at_utc':now(),'source_out':str(SOURCE),'source_protocol_sha256':sha(SOURCE/'protocol.json'),'source_cases_sha256':sha(SOURCE/'cases.json'),'script_sha256':sha(Path(__file__)),
   'authorization':'Root explicitly authorized draining current two phases at original902-second controller bounds, then a new uniformly staged900command/900audit/3600workflow pass for not-yet-started work and admitted methods gaps. No frozen source code/results changes.',
   'operation':'Validate exact owned controller and source path; SIGSTOP controller only to prevent scheduling. Existing isolated worker groups finish naturally until their original elapsed902s outer deadlines, enforced externally. After every active group has no living work, kill stopped controller. Preserve all raw records; missing source result is explained only in this drain ledger.',
   'workers_maximum':2,'original_phase_outer_seconds':902,'no_new_installer_or_resolver_invocation':True,'no_files_deleted_or_moved':True}
  dump(PLAN,plan);print(json.dumps({'plan_sha256':sha(PLAN),'script_sha256':plan['script_sha256']}),flush=True);return
 assert args.run and not LEDGER.exists()
 plan=json.loads(PLAN.read_text());assert sha(Path(__file__))==plan['script_sha256']
 assert sha(SOURCE/'protocol.json')==plan['source_protocol_sha256'] and sha(SOURCE/'cases.json')==plan['source_cases_sha256']
 controllers=[r for r in all_processes() if matches(r,'--run')];assert len(controllers)==1,controllers
 controller=controllers[0];assert controller['pid']!=os.getpid() and same(controller)
 ledger={'schema':plan['schema'],'status':'drain_in_progress','started_at_utc':now(),'plan_sha256':sha(PLAN),'source_out':str(SOURCE),'source_protocol_sha256':sha(SOURCE/'protocol.json'),'source_cases_sha256':sha(SOURCE/'cases.json'),'controller':controller,'actions':[],'workers':[]}
 dump(LEDGER,ledger)
 os.kill(controller['pid'],signal.SIGSTOP);ledger['actions'].append({'at_utc':now(),'signal':'SIGSTOP','pid':controller['pid'],'purpose':'Prevent new phases from scheduling; preserve active phase work.'});dump(LEDGER,ledger)
 time.sleep(.25)
 assert process(controller['pid'])['state'] in ('T','t')
 workers=[r for r in all_processes() if matches(r,'--worker')];assert len(workers)<=2
 ticks=os.sysconf('SC_CLK_TCK');uptime=float(Path('/proc/uptime').read_text().split()[0]);monotonic=time.monotonic()
 for w in workers:
  assert w['pgid']==w['pid']
  w['elapsed_seconds_at_drain']=round(uptime-w['start_ticks']/ticks,3)
  w['deadline_monotonic']=monotonic+max(0,902-w['elapsed_seconds_at_drain'])
  w['outcome']='pending';w['raw_before']=record_source_result(w)
 ledger['workers']=workers;dump(LEDGER,ledger)
 while any(w['outcome']=='pending' for w in workers):
  for w in workers:
   if w['outcome']!='pending':continue
   live=[p for p in all_processes() if p['pgid']==w['pgid'] and p['state']!='Z']
   if not live:
    w.update(outcome='active_phase_finished_naturally',finished_at_utc=now(),raw_after=record_source_result(w));dump(LEDGER,ledger)
   elif time.monotonic()>=w['deadline_monotonic']:
    assert same(w)
    os.killpg(w['pgid'],signal.SIGKILL)
    w.update(outcome='external_enforcement_of_original_phase_budget',finished_at_utc=now(),raw_after=record_source_result(w))
    ledger['actions'].append({'at_utc':now(),'signal':'SIGKILL','pgid':w['pgid'],'purpose':'Original902s outer phase deadline; no new budget or fake source result.'});dump(LEDGER,ledger)
  if any(w['outcome']=='pending' for w in workers):time.sleep(1)
 for w in workers:
  assert not [p for p in all_processes() if p['pgid']==w['pgid'] and p['state']!='Z']
 assert same(controller) and process(controller['pid'])['state'] in ('T','t')
 os.kill(controller['pid'],signal.SIGKILL);ledger['actions'].append({'at_utc':now(),'signal':'SIGKILL','pid':controller['pid'],'purpose':'Terminate stopped scheduler after all active phases finished or hit original bound.'})
 time.sleep(.3)
 ledger.update(status='controlled_method_repair_drain_completed',finished_at_utc=now(),all_owned_living_processes_terminated=not any(matches(r,'--worker') or matches(r,'--run') for r in all_processes() if r['state']!='Z'),source_protocol_unchanged=sha(SOURCE/'protocol.json')==plan['source_protocol_sha256'],source_cases_unchanged=sha(SOURCE/'cases.json')==plan['source_cases_sha256'],source_results_not_written_by_drain=True,files_deleted_or_moved=False)
 assert ledger['all_owned_living_processes_terminated'] and ledger['source_protocol_unchanged'] and ledger['source_cases_unchanged']
 dump(LEDGER,ledger);print(json.dumps({'status':ledger['status'],'ledger_sha256':sha(LEDGER),'workers':[{k:v for k,v in w.items() if k in ('pid','outcome','raw_after')} for w in workers]}),flush=True)
if __name__=='__main__':main()
