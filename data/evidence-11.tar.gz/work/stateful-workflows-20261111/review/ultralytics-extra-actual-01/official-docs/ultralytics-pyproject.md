# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

# Overview:
# This pyproject.toml file manages the build, packaging, and distribution of the Ultralytics library.
# It defines essential project metadata, dependencies, and settings used to develop and deploy the library.

# Key Sections:
# - [build-system]: Specifies the build requirements and backend (e.g., setuptools, wheel).
# - [project]: Includes details like name, version, description, authors, dependencies and more.
# - [project.optional-dependencies]: Provides additional, optional packages for extended features.
# - [tool.*]: Configures settings for various tools (pytest, yapf, etc.) used in the project.

# Installation:
# The Ultralytics library can be installed using the command: 'pip install ultralytics'
# For development purposes, you can install the package in editable mode with: 'pip install -e .'
# This approach allows for real-time code modifications without the need for re-installation.

# Documentation:
# For comprehensive documentation and usage instructions, visit: https://docs.ultralytics.com

[build-system]
requires = ["setuptools>=70.0.0,<=84.0.0", "wheel"]
build-backend = "setuptools.build_meta"

# Project settings -----------------------------------------------------------------------------------------------------
[project]
name = "ultralytics"
dynamic = ["version"]
description = "Ultralytics YOLO 🚀 for SOTA object detection, instance segmentation, semantic segmentation, depth estimation, classification, pose estimation, oriented object detection, and multi-object tracking."
readme = "README.md"
requires-python = ">=3.8"
license = { "text" = "AGPL-3.0" }
keywords = ["machine-learning", "deep-learning", "computer-vision", "ML", "DL", "AI", "RT-DETR", "SAM3", "YOLO", "YOLOv3", "YOLOv5", "YOLOv8", "YOLO11", "YOLO26", "Platform", "Ultralytics"]
authors = [
    { name = "Glenn Jocher", email = "glenn.jocher@ultralytics.com" },
    { name = "Jing Qiu", email = "jing.qiu@ultralytics.com" },
]
maintainers = [
    { name = "Ultralytics", email = "hello@ultralytics.com" },
]
classifiers = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Developers",
    "Intended Audience :: Education",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: GNU Affero General Public License v3 or later (AGPLv3+)",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Programming Language :: Python :: 3.14",
    "Programming Language :: Python :: 3.15",
    "Topic :: Software Development",
    "Topic :: Scientific/Engineering",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Topic :: Scientific/Engineering :: Image Recognition",
    "Operating System :: POSIX :: Linux",
    "Operating System :: MacOS",
    "Operating System :: Microsoft :: Windows",
]

# Required dependencies ------------------------------------------------------------------------------------------------
dependencies = [
    "numpy>=1.23.0; platform_system != 'Darwin'",
    "numpy>=1.23.0,!=2.0.*,!=2.1.*,!=2.2.*,!=2.3.0,!=2.3.1,!=2.3.2,!=2.3.3,!=2.3.4; platform_system == 'Darwin'",  # Accelerate matmul bug fixed in 2.3.5
    "matplotlib>=3.3.0",
    "opencv-python>=4.7.0,!=4.13.0.90", # 4.13.0.90 FIPS selftest crash https://github.com/ultralytics/ultralytics/issues/23373
    "pillow>=7.1.2",
    "requests>=2.23.0",
    "torch>=1.8.0",
    "torch>=1.8.0,!=2.4.0; sys_platform == 'win32'", # Windows CPU errors w/ 2.4.0 https://github.com/ultralytics/ultralytics/issues/15049
    "torchvision>=0.9.0",
    "psutil>=5.8.0", # system utilization
    "polars>=0.20.0",
    "nvidia-ml-py>=12.0.0", # NVIDIA GPU monitoring https://pypi.org/project/nvidia-ml-py
    "ultralytics-thop>=2.2.4", # FLOPs computation https://github.com/ultralytics/thop
    "ultralytics-platform>=0.1.102; python_version >= '3.11'",
]

# Optional dependencies ------------------------------------------------------------------------------------------------
[project.optional-dependencies]
dev = [
    "ipython",
    "pytest",
    "pytest-cov",
    "pytest-xdist>=3.0.0",
    "coverage[toml]",
    "zensical>=0.0.58; python_version >= '3.10'",
    "minijinja>=2.0.0", # render docs macros without mkdocs-macros-plugin
]
export-base = [
    "onnx>=1.12.0; platform_system != 'Darwin'", # ONNX export
    "onnx>=1.12.0,<1.18.0; platform_system == 'Darwin' and python_version < '3.13'",  # TF inference hanging on MacOS (tested up to onnx==1.20.0)
    "onnx>=1.20.0; platform_system == 'Darwin' and python_version >= '3.13'",
    "onnxslim>=0.1.82",
    # ONNX export validation and inference. Jetson jobs provide custom aarch64 onnxruntime-gpu wheels.
    "onnxruntime<1.20.0; python_version < '3.11' and (platform_machine != 'aarch64' or platform_system != 'Linux')",
    "onnxruntime>=1.20.0; python_version >= '3.11'",
]
export-openvino = [
    "nncf>=2.14.0; python_version >= '3.9'",  # OpenVINO INT8 export
    "openvino>=2024.0.0",  # OpenVINO export
    "packaging>=26.0; platform_machine == 'aarch64' and platform_system == 'Linux' and python_version >= '3.9'", # NNCF on Linux ARM64
]
export-legacy-torch = [
    "numpy<2; python_version < '3.13'",  # legacy torch wheels break with NumPy 2 and stop at Python 3.12
    "setuptools<81.0.0; python_version >= '3.9'",  # legacy torch's torch_version imports pkg_resources, removed in setuptools>=81
    "nncf<3.0.0; python_version >= '3.9'",  # nncf>=3 reads torch.uint16, added in torch 2.3
]
export-tensorflow = [
    "numpy<2.0.0; python_version < '3.13'", # TF 2.20 compatibility
    "tensorflow>=2.0.0,<=2.19.0; python_version < '3.13'", # TF bug https://github.com/ultralytics/ultralytics/issues/5161
    "tensorflow>2.19.0; python_version >= '3.13'",
    "ydf<0.13.0; platform_machine != 'aarch64' and python_version <= '3.12'", # ydf>=0.13 has protobuf gencode 6.x but tensorflow<=2.19 requires protobuf<6
    "googleapis-common-protos<1.74.0; python_version <= '3.12'", # >=1.74.0 uses protobuf gencode 7.34.1, incompatible with tensorflow<=2.19 (protobuf<6) and breaks ray[tune] import
    "tensorstore>=0.1.63; platform_machine == 'aarch64' and python_version >= '3.9'", # for TF Raspberry Pi exports
    "h5py!=3.11.0; platform_machine == 'aarch64'", # fix h5py build issues due to missing aarch64 wheels in 3.11 release
]
export-coreai = [
    "coreai-torch>=0.4.3; ((platform_system == 'Darwin' and platform_machine == 'arm64') or (platform_system == 'Linux' and platform_machine == 'x86_64')) and python_version >= '3.11' and python_version < '3.15'",  # Core AI export
]
export-coreml = [
    "numpy<=2.3.5; platform_system != 'Windows' and python_version <= '3.13'",  # pin until CoreML>9.0 fixes numpy>=2.4 int() cast crash
    "coremltools>=9.0; platform_system != 'Windows' and python_version <= '3.13'", # CoreML supported on macOS and Linux
    "scikit-learn>=1.3.2; platform_system != 'Windows' and python_version <= '3.13'", # CoreML k-means quantization
]
export-executorch = [
    "executorch",
    "numpy<=2.3.5",
]
export-deepx = [
    "dx_com>=2.5.0",
    "numpy<2; python_version < '3.13'",  # NumPy 1.x wheels stop at Python 3.12
]
export-xilinx = [  # AMD Xilinx Versal AI Edge Gen 2 export, AMD Quark quantizer
    "amd-quark>=0.13.0,<0.14.0; platform_system == 'Linux' and python_version >= '3.11' and python_version < '3.14'",
]
export-litert = [  # LiteRT export, Linux x86 and macOS (litert-torch trace + ai-edge-litert/quantizer)
    "litert-torch>=0.10.0; ((platform_system == 'Linux' and platform_machine == 'x86_64') or platform_system == 'Darwin') and python_version >= '3.10'",
    "ai-edge-litert>=2.3.0; ((platform_system == 'Linux' and platform_machine == 'x86_64') or platform_system == 'Darwin') and python_version >= '3.10'",
    "ai-edge-quantizer>=0.10.0; ((platform_system == 'Linux' and platform_machine == 'x86_64') or platform_system == 'Darwin') and python_version >= '3.10'",
]
export = [
    "ultralytics[export-base]",
    "ultralytics[export-openvino]",
    "ultralytics[export-tensorflow]",
    "ultralytics[export-coreml]",
    "ultralytics[export-litert]",
    # Raspberry Pi Python 3.11 ExecuTorch inference requires the last known-good Linux ARM64 Torch 2.14 stack.
    "torch>=2.12.0,<2.15.0; platform_system == 'Linux' and platform_machine == 'aarch64' and python_version == '3.11'",
]
solutions = [
    "shapely>=2.0.0",    # shapely for point and polygon data matching
    "lap>=0.5.12",  # for solution tracking linear assignment
    # CLIP for similarity search auto-installs on first use via ultralytics.nn.text_model (https://github.com/ultralytics/CLIP)
    "streamlit>=1.51.0; python_version >= '3.10'",    # for live inference in a web browser, e.g. `yolo solutions inference`
    "streamlit>=1.29.0,<1.51.0; python_version < '3.10' and (platform_machine != 'aarch64' or platform_system != 'Linux')",
    "flask>=3.0.1",  # for similarity search solution
]
llm = [
    "openai>=2.0.0",
]
logging = [
    "wandb", # https://docs.ultralytics.com/integrations/weights-biases
    "tensorboard",  # https://docs.ultralytics.com/integrations/tensorboard
    "mlflow",  # https://docs.ultralytics.com/integrations/mlflow
]
extra = [
    "ipython", # interactive notebook
    "albumentations>=1.4.6", # training augmentations
    "faster-coco-eval>=1.6.7", # COCO mAP
]
typing = [
    "types-pillow",
    "types-psutil",
    "types-requests",
    "types-shapely",
]

[project.urls]
"Homepage" = "https://ultralytics.com"
"Source" = "https://github.com/ultralytics/ultralytics"
"Documentation" = "https://docs.ultralytics.com"
"Bug Reports" = "https://github.com/ultralytics/ultralytics/issues"
"Changelog" = "https://github.com/ultralytics/ultralytics/releases"

[project.scripts]
yolo = "ultralytics.cfg:entrypoint"
ultralytics = "ultralytics.cfg:entrypoint"

# Tools settings -------------------------------------------------------------------------------------------------------
[tool.setuptools]  # configuration specific to the `setuptools` build backend.
packages = { find = { where = ["."], include = ["ultralytics", "ultralytics.*"] } }
package-data = { "ultralytics" = ["**/*.yaml", "**/*.sh"], "ultralytics.assets" = ["*.jpg"], "ultralytics.solutions.templates" = ["*.html"]}

[tool.setuptools.dynamic]
version = { attr = "ultralytics.__version__" }

[tool.uv]  # extras pinning incompatible NumPy/Torch stacks, never resolved together; pip installs are unaffected
conflicts = [
    [{ extra = "export" }, { extra = "export-executorch" }, { extra = "export-legacy-torch" }],
    [{ extra = "export-deepx" }, { extra = "export-executorch" }, { extra = "export-tensorflow" }],
    [{ extra = "export-legacy-torch" }, { extra = "export-openvino" }],
    [{ extra = "export-legacy-torch" }, { extra = "export-tensorflow" }],
    [{ extra = "export-xilinx" }, { extra = "export" }, { extra = "export-legacy-torch" }],
    [{ extra = "export-xilinx" }, { extra = "export-tensorflow" }, { extra = "export-deepx" }],
]

[tool.pytest.ini_options]
addopts = "--doctest-modules --durations=30 --color=yes"
markers = [
    "slow: skip slow tests unless --slow is set",
]
filterwarnings = [
    "ignore::torch.jit.TracerWarning", # pytest discards the import-time filter in ultralytics/utils/__init__.py
]
norecursedirs = [".git", "dist", "build"]

[tool.coverage.run]
source = ["ultralytics/"]
data_file = "tests/.coverage"
omit = ["ultralytics/utils/callbacks/*"]

[tool.isort]
line_length = 120
multi_line_output = 0

[tool.yapf]
based_on_style = "pep8"
spaces_before_comment = 2
column_limit = 120
coalesce_brackets = true
spaces_around_power_operator = true
space_between_ending_comma_and_closing_bracket = true
split_before_closing_bracket = false
split_before_first_argument = false

[tool.ruff]
line-length = 120
target-version = "py38"

[tool.ruff.format]
docstring-code-format = true

[tool.ruff.lint.pydocstyle]
convention = "google"

[tool.docformatter]
wrap-summaries = 120
wrap-descriptions = 120
pre-summary-newline = true
close-quotes-on-newline = true
in-place = true

[tool.codespell]
ignore-words-list = "grey,writeable,finalY,RepResNet,Idenfy,WIT,Smoot,EHR,ROUGE,ALS,iTerm,Carmel,FPR,Hach,Calle,ore,COO,MOT,crate,nd,ned,strack,dota,ane,segway,fo,gool,winn,commend,bloc,nam,afterall,skelton,goin,alls,manger,trough,cann"
skip = "*.pt,*.pth,*.torchscript,*.onnx,*.tflite,*.pb,*.bin,*.param,*.mlmodel,*.engine,*.npy,*.data*,*.csv,*pnnx*,*venv*,*translat*,*lock*,__pycache__*,*.ico,*.jpg,*.png,*.webp,*.avif,*.mp4,*.mov,/runs,/.git,./docs/??/*.md,./docs/mkdocs_??.yml"
