"""Read-only original-wheel .data/data -> saved installed RECORD proof.

This adds evidence without changing the frozen auditor or its original unknowns.
Historical states are not reconstructed from their now-repaired environment.
"""
import base64
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile
from packaging.utils import canonicalize_name

ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / "work/stateful-workflows-20261111/review/ultralytics-extra-actual-01"


def load(path):
    return json.loads(path.read_bytes())


def evidence(path):
    return {"path": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


assert (RUN / "results.json").exists(), "Wait for the bounded actual driver to finish"
result = load(RUN / "results.json")
assert result["status"] == "actual_workflow_complete_independent_admission_pending"
wheels = {}
for path in (RUN / "preparation").glob("*.json"):
    for wheel in load(path)["wheels"]:
        key = (wheel["name"], wheel["version"])
        if key in wheels:
            assert wheels[key]["sha256"] == wheel["sha256"]
        wheels[key] = wheel

rows = []
for item in result["stages"]:
    stage = RUN / "stages" / item["label"]
    inventory = load(stage / "installed.json")
    installed = {canonicalize_name(dist["name"]): dist for dist in inventory["installed"]}
    audit = load(stage / "file-audit.json")
    audited = {canonicalize_name(dist["name"]): dist for dist in audit["distributions"]}
    for unknown in audit["unknown"]:
        assert unknown["kind"] == "wheel_data_path_transform"
        name = canonicalize_name(unknown["name"])
        dist = installed[name]
        wheel = wheels[name, dist["version"]]
        member = unknown["path"]
        prefix, separator, tail = member.partition(".data/data/")
        assert separator and tail and not Path(tail).is_absolute() and ".." not in Path(tail).parts
        original = wheel["payload"][member]
        with zipfile.ZipFile(wheel["archive_path"]) as archive:
            raw_member = archive.read(member)
        assert hashlib.sha256(raw_member).hexdigest() == original["sha256"] and len(raw_member) == original["bytes"]
        record_path = stage / "metadata" / name / "RECORD"
        records = list(csv.reader(record_path.read_text().splitlines()))
        hashed_records = [row for row in records if len(row) >= 3 and row[1]]
        # Original frozen auditor checked every hashed RECORD entry at that stage.
        assert audited[name]["record_hashes_checked"] == len(hashed_records)
        expected_record = "../../../" + tail
        matches = [row for row in records if row[0] == expected_record]
        assert len(matches) == 1, (item["label"], name, expected_record)
        record = matches[0]
        algorithm, encoded = record[1].split("=", 1)
        assert algorithm == "sha256"
        decoded = base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)).hex()
        assert decoded == original["sha256"] and int(record[2]) == original["bytes"]
        installed_path = str((Path(dist["dist_info"]).parent / record[0]).resolve())
        # A failure at this historical file would have been recorded by RECORD path.
        assert not any(v.get("path") == installed_path for v in audit["violations"])
        rows.append({
            "stage": item["label"], "distribution": name, "version": dist["version"],
            "original_member": member, "original_wheel_sha256": wheel["sha256"],
            "original_bytes": original["bytes"], "original_sha256": original["sha256"],
            "installed_record_entry": record, "installed_record": evidence(record_path),
            "inventory": evidence(stage / "installed.json"), "frozen_file_audit": evidence(stage / "file-audit.json"),
            "record_hashes_checked": audited[name]["record_hashes_checked"],
            "entire_saved_record_hashed_entry_count": len(hashed_records),
            "original_payload_equals_saved_record_hash_and_size": True,
            "original_member_bytes_rehashed_at_addendum": True,
            "historical_actual_record_check_reported_no_failure_for_this_path": True,
            "proof_type": "Original wheel hash/size -> saved installed RECORD hash/size -> frozen all-RECORD actual-file checks. Not a later environment read used to infer an earlier state.",
        })

report = {
    "schema": "ultralytics-original-data-path-addendum-v1",
    "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
    "review_tool": evidence(Path(__file__).resolve()),
    "actual_result": evidence(RUN / "results.json"),
    "scope": "Only the original auditor's .data/data original-path mapping unknowns. Original reports remain unchanged. Each exact official wheel payload equals its saved installed RECORD entry; complete historical hashed-RECORD checks provide actual-file evidence at that state.",
    "rows": rows,
    "counts": {"saved_stage_unknown_entries": len(rows), "distinct_original_data_members": len({(row["distribution"], row["version"], row["original_member"]) for row in rows}), "covered_by_exact_original_to_record_chain": len(rows), "unresolved_original_data_path_entries": 0},
    "limits": ["This addendum does not turn damaged cv2 entries into passes; the original actual file violations remain.", "Original unknown counts are retained in raw reports. The supplementary proof is explicit and separate.", "This is read-only analysis, not another package installation or affected project."],
}
target = RUN / "original-data-path-addendum.json"
assert not target.exists()
target.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"output": evidence(target), "counts": report["counts"]}))
