"""Independent pre-sweep closure attestation. Read-only toward experiment data."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "work/stateful-workflows-20261111/published"
REVIEW = ROOT / "work/stateful-workflows-20261111/review"
REG = REVIEW / "published-saved-inventory-sweep-v3/registration.json"


def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def ev(path):
    path = Path(path).resolve()
    return {"path": str(path.relative_to(ROOT)), "sha256": digest(path)}


def process_snapshot(source_directories):
    """Match owned experimental controllers and install/resolve subprocesses only."""
    prefixes = [str(path.resolve()) for path in source_directories]
    owned = {"stateful_real_workflows_1111.py", "recover_stateful_preparation_1111.py", "recover_stateful_workflow_methods_1111.py", "continue_published_staged_v2_1111.py"}
    matches, unreadable = [], []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid(): continue
        try:
            if proc.stat().st_uid != os.getuid(): continue
            state = (proc / "stat").read_text().rpartition(")")[2].split()[0]
            if state == "Z": continue
            args = [value for value in (proc / "cmdline").read_bytes().decode(errors="replace").split("\0") if value]
            if not args: continue
            controller = any(Path(value).name in owned for value in args) and any(flag in args for flag in ("--run", "--worker"))
            native_operation = any(word in args for word in ("install", "sync", "lock")) and ("uv" in Path(args[0]).name or "python" in Path(args[0]).name)
            # A different owned service may hide its cwd. Only potential
            # experimental operations need cwd/source attribution.
            if not (controller or native_operation): continue
            cwd = str((proc / "cwd").resolve())
        except (FileNotFoundError, ProcessLookupError): continue
        except (OSError, PermissionError) as error:
            unreadable.append({"pid": int(proc.name), "reason": str(error)}); continue
        relation = any(cwd == prefix or cwd.startswith(prefix + "/") for prefix in prefixes)
        relation = relation or any(any(value.startswith(prefix + "/") or value == prefix for prefix in prefixes) for value in args)
        if not relation: continue
        if controller or native_operation: matches.append({"pid": int(proc.name), "cwd": cwd, "argv": args, "state": state})
    return {"checked_at_utc": datetime.now(timezone.utc).isoformat(), "active_actual_workers": len(matches), "processes": matches, "unreadable_owned_processes": unreadable, "scope": "Owned exact experimental --run/--worker scripts and source-related native install/sync/lock commands. Read-only reviewers and zombies excluded. Point-in-time check, not continuous monitoring."}


def main():
    handoff = BASE / "finalization-inputs.json"
    assert digest(handoff) == "99b1e430a0d964c1cf71e06dba520808f1aa3b89ba1f2481651d775e39325310"
    h = load(handoff)
    assert h["all_99_slots_closed"] and h["logical_slots"] == 99 and h["registered_roots"] == 33
    assert h["active_actual_workers"] == 0 and h["inputs_unchanged"] and h["core_unchanged"]
    assert h["static_selected"] == h["semantic_applicable"] == 84
    for key in ("effective_ledger", "staged_summary", "staged_protocol", "no_active_actual_workers"):
        assert ev(ROOT / h[key]["path"]) == h[key]
    ledger, summary = load(ROOT / h["effective_ledger"]["path"]), load(ROOT / h["staged_summary"]["path"])
    producer_process = load(ROOT / h["no_active_actual_workers"]["path"])
    assert ledger["is_final"] and ledger["logical_root_sequence_rows"] == 99
    rows = ledger["rows"]
    assert len(rows) == 99 and len({(row["canonical_name"], row["workflow"]) for row in rows}) == 99
    assert len({row["canonical_name"] for row in rows}) == 33
    closure = dict(Counter(row["closure_state"] for row in rows))
    assert closure == h["closure_counts"] == ledger["closure_counts"] == {"completed": 33, "closed_unmeasured": 51, "not_applicable": 15}
    assert sum(row["semantic_applicable"] for row in rows) == sum(row["static_selected"] for row in rows) == 84
    assert not any("pending" in row["closure_state"] or row["closure_state"] == "candidate" for row in rows)
    assert sum(row["completed_actual_sequence"] for row in rows) == 33
    assert all(row["logical_unit_count"] == 1 for row in rows)
    assert summary["inputs_unchanged"] and summary["core_unchanged"] and summary["original_data_preserved"]
    assert summary["protocol_sha256"] == h["staged_protocol"]["sha256"] and len(summary["results"]) == 33
    assert len({row["name"] for row in summary["results"]}) == 33
    assert not producer_process["processes"] and producer_process["active_actual_workers"] == 0
    assert producer_process["source_summary"] == h["staged_summary"]
    reg = load(REG)
    assert digest(REG) == "c17eda86c63db09add16135daabc968ac512a668c4bfb330cc7f944c5b230a4f"
    sources, frozen_cases = [], None
    for source in reg["sources"]:
        for key in ("protocol", "cases"): assert ev(ROOT / source[key]["path"]) == source[key]
        cases = {row["canonical_name"]: row for row in load(ROOT / source["cases"]["path"])["roots"]}
        if frozen_cases is None: frozen_cases = cases
        else: assert cases == frozen_cases
        sources.append(ROOT / source["directory"])
    for row in rows:
        case = frozen_cases[row["canonical_name"]]
        assert row["current_pin"] == case["request"] and row["target_python"] == case["target_python"]
    for path, expected in reg["core29_expected"].items(): assert digest(ROOT / path) == expected
    for key in ("script", "fixed_point_checker", "core29_baseline"): assert ev(ROOT / reg[key]["path"]) == reg[key]
    snapshot = process_snapshot(sources)
    assert not snapshot["processes"] and not snapshot["unreadable_owned_processes"], snapshot
    process_path = BASE / "independent-final-no-active-workers-before-sweep.json"
    assert not process_path.exists()
    process_path.write_text(json.dumps(snapshot, indent=2) + "\n")
    assert ev(handoff)["sha256"] == "99b1e430a0d964c1cf71e06dba520808f1aa3b89ba1f2481651d775e39325310"
    for key in ("effective_ledger", "staged_summary", "staged_protocol", "no_active_actual_workers"):
        assert ev(ROOT / h[key]["path"]) == h[key]
    result = {
        "schema": "published-99-slots-closed-attestation-v1", "attested_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "closed_with_coverage_limits_saved_inventory_sweep_pending", "is_final": True,
        "all_99_slots_closed": True, "logical_slots": 99, "registered_roots": 33,
        "static_selected": 84, "semantic_applicable": 84, "active_actual_workers": 0,
        "closure_counts": closure, "effective_ledger": h["effective_ledger"], "staged_summary": h["staged_summary"], "staged_protocol": h["staged_protocol"],
        "producer_handoff": ev(handoff), "producer_no_active_actual_workers": h["no_active_actual_workers"],
        "independent_no_active_actual_workers": ev(process_path), "registered_sources": reg["sources"],
        "frozen_sweep_registration": ev(REG), "core29_unchanged": True, "independent_registered_source_inputs_unchanged": True,
        "producer_all_registered_inputs_unchanged": summary["inputs_unchanged"],
        "input_validation_scope": "Independently rehashed the handoff, final ledger/summary/protocol/process record, three frozen source case/protocol pairs, frozen checker/helper and29 core files. Producer summary separately seals its complete registered input world; complete archive/payload bytes were not rehashed here.",
        "independent_closure_rows_verified": 99, "native_case_bindings_verified": 99,
        "readonly_composite_proofs_count": 3, "readonly_proofs_add_actual_installations": 0,
        "new_actual_installations_performed_by_this_attestation": 0,
        "metadata_health_asserted_by_this_attestation": False,
        "limits": ["The final marker applies to workflow closure only.33 completed/51 closed-unmeasured/15 nonapplicable are distinct; no51 coverage gaps become negatives.", "The saved-inventory final sweep is a separate later immutable artifact. This pre-sweep attestation intentionally does not reference it, avoiding a hash cycle.", "Point-in-time quiescence and producer closure do not imply package-wide health, all public candidate coverage, file/payload integrity or new ecosystem novelty."],
        "attestation_tool": ev(Path(__file__).resolve()),
    }
    target = BASE / "closure-attestation.json"
    assert not target.exists()
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"attestation": ev(target), "independent_process_check": ev(process_path), "closure_counts": closure}))


if __name__ == "__main__": main()
